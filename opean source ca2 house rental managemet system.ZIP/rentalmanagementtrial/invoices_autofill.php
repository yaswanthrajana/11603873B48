<?php

	$currDir = dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");

	handle_maintenance();

	header('Content-type: text/javascript; charset=' . datalist_db_encoding);

	$table_perms = getTablePermissions('invoices');
	if(!$table_perms[0]){ die('// Access denied!'); }

	$mfk = $_GET['mfk'];
	$id = makeSafe($_GET['id']);
	$rnd1 = intval($_GET['rnd1']); if(!$rnd1) $rnd1 = '';

	if(!$mfk){
		die('// No js code available!');
	}

	switch($mfk){

		case 'tenant':
			if(!$id){
				?>
				$j('#phone<?php echo $rnd1; ?>').html('&nbsp;');
				$j('#house<?php echo $rnd1; ?>').html('&nbsp;');
				<?php
				break;
			}
			$res = sql("SELECT `tenants`.`id` as 'id', `tenants`.`fullname` as 'fullname', `tenants`.`gender` as 'gender', `tenants`.`national_id` as 'national_id', `tenants`.`phone_number` as 'phone_number', `tenants`.`email` as 'email', if(`tenants`.`registration_date`,date_format(`tenants`.`registration_date`,'%m/%d/%Y'),'') as 'registration_date', IF(    CHAR_LENGTH(`houses1`.`house_number`), CONCAT_WS('',   `houses1`.`house_number`), '') as 'house', `tenants`.`agreement_document` as 'agreement_document', `tenants`.`status` as 'status', if(`tenants`.`exit_date`,date_format(`tenants`.`exit_date`,'%m/%d/%Y'),'') as 'exit_date' FROM `tenants` LEFT JOIN `houses` as houses1 ON `houses1`.`id`=`tenants`.`house`  WHERE `tenants`.`id`='{$id}' limit 1", $eo);
			$row = db_fetch_assoc($res);
			?>
			$j('#phone<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['phone_number']))); ?>&nbsp;');
			$j('#house<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['house']))); ?>&nbsp;');
			<?php
			break;


	}

?>