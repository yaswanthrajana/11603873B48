<?php

	$currDir = dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");

	handle_maintenance();

	header('Content-type: text/javascript; charset=' . datalist_db_encoding);

	$table_perms = getTablePermissions('payments');
	if(!$table_perms[0]){ die('// Access denied!'); }

	$mfk = $_GET['mfk'];
	$id = makeSafe($_GET['id']);
	$rnd1 = intval($_GET['rnd1']); if(!$rnd1) $rnd1 = '';

	if(!$mfk){
		die('// No js code available!');
	}

	switch($mfk){

		case 'tenant':
			if(!$id){
				?>
				$j('#house<?php echo $rnd1; ?>').html('&nbsp;');
				$j('#year<?php echo $rnd1; ?>').html('&nbsp;');
				$j('#month<?php echo $rnd1; ?>').html('&nbsp;');
				$j('#expected_amount<?php echo $rnd1; ?>').html('&nbsp;');
				<?php
				break;
			}
			$res = sql("SELECT `invoices`.`id` as 'id', IF(    CHAR_LENGTH(`tenants1`.`fullname`) || CHAR_LENGTH(`tenants1`.`national_id`), CONCAT_WS('',   `tenants1`.`fullname`, ' ID: ', `tenants1`.`national_id`), '') as 'tenant', IF(    CHAR_LENGTH(`tenants1`.`phone_number`), CONCAT_WS('',   `tenants1`.`phone_number`), '') as 'phone', IF(    CHAR_LENGTH(`houses1`.`house_number`), CONCAT_WS('',   `houses1`.`house_number`), '') as 'house', `invoices`.`year` as 'year', `invoices`.`month` as 'month', `invoices`.`particulars` as 'particulars', `invoices`.`total` as 'total', `invoices`.`status` as 'status', `invoices`.`comments` as 'comments' FROM `invoices` LEFT JOIN `tenants` as tenants1 ON `tenants1`.`id`=`invoices`.`tenant` LEFT JOIN `houses` as houses1 ON `houses1`.`id`=`tenants1`.`house`  WHERE `invoices`.`id`='{$id}' limit 1", $eo);
			$row = db_fetch_assoc($res);
			?>
			$j('#house<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['house']))); ?>&nbsp;');
			$j('#year<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['year']))); ?>&nbsp;');
			$j('#month<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['month']))); ?>&nbsp;');
			$j('#expected_amount<?php echo $rnd1; ?>').html('<?php echo addslashes(str_replace(array("\r", "\n"), '', nl2br($row['total']))); ?>&nbsp;');
			<?php
			break;


	}

?>